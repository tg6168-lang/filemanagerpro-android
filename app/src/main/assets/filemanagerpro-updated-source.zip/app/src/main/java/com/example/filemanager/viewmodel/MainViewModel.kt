package com.example.filemanager.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.filemanager.archive.ArchiveCompressionConfig
import com.example.filemanager.archive.ArchiveManager
import com.example.filemanager.archive.ArchivePasswordRequiredException
import com.example.filemanager.extensions.GitHubApkPushManager
import com.example.filemanager.extensions.PrefsGitHubTokenStorage
import com.example.filemanager.model.*
import com.example.filemanager.utils.CrossWindowTransferBus
import com.example.filemanager.utils.CrossWindowTransferEvent
import com.example.filemanager.utils.FileOperations
import com.example.filemanager.utils.FileUtils
import com.example.filemanager.utils.SafManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed class ScreenDestination {
    data object Home : ScreenDestination()
    data object Files : ScreenDestination()
    data object GameData : ScreenDestination()
    data object Analyzer : ScreenDestination()
    data object SourcePackage : ScreenDestination()
    data object Settings : ScreenDestination()
    data class TextViewer(val file: File) : ScreenDestination()
    data class ApkInspector(val file: File) : ScreenDestination()
    data class SqliteViewer(val file: File) : ScreenDestination()
    data class HexViewer(val file: File) : ScreenDestination()
    data class ArchiveViewer(val file: File) : ScreenDestination()
    data class MediaViewer(val file: File, val type: FileType) : ScreenDestination()
    data object DualPane : ScreenDestination()
}

enum class DualPaneSplit {
    VERTICAL,   // Top / Bottom
    HORIZONTAL  // Left / Right
}

enum class AppOrientationMode(val label: String) {
    AUTO("Tự động"),
    PORTRAIT("Chân dung"),
    LANDSCAPE("Xoay ngang")
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("file_manager_pro_prefs", Context.MODE_PRIVATE)

    val gitHubPushManager = GitHubApkPushManager(PrefsGitHubTokenStorage(application))

    private val _currentScreen = MutableStateFlow<ScreenDestination>(ScreenDestination.Home)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    private val _navigationHistory = mutableListOf<ScreenDestination>()

    // Primary Pane Directory & Backstack
    private val _currentDirectory = MutableStateFlow<File>(Environment.getExternalStorageDirectory())
    val currentDirectory: StateFlow<File> = _currentDirectory.asStateFlow()

    private val _directoryBackStack = mutableListOf<File>()

    private val _activeCategoryTitle = MutableStateFlow<String?>(null)
    val activeCategoryTitle: StateFlow<String?> = _activeCategoryTitle.asStateFlow()

    private val _fileItems = MutableStateFlow<List<FileItem>>(emptyList())
    val fileItems: StateFlow<List<FileItem>> = _fileItems.asStateFlow()

    private val _isLoading = MutableStateFlow<Boolean>(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    // Secondary Pane (Dual Pane / Split Screen)
    private val _isDualPaneMode = MutableStateFlow(false)
    val isDualPaneMode: StateFlow<Boolean> = _isDualPaneMode.asStateFlow()

    private val _dualPaneSplit = MutableStateFlow(DualPaneSplit.VERTICAL)
    val dualPaneSplit: StateFlow<DualPaneSplit> = _dualPaneSplit.asStateFlow()

    private val _secondaryDirectory = MutableStateFlow<File>(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            ?.takeIf { it.exists() && it.canRead() } ?: Environment.getExternalStorageDirectory()
    )
    val secondaryDirectory: StateFlow<File> = _secondaryDirectory.asStateFlow()

    private val _secondaryFileItems = MutableStateFlow<List<FileItem>>(emptyList())
    val secondaryFileItems: StateFlow<List<FileItem>> = _secondaryFileItems.asStateFlow()

    private val _secondaryBackStack = mutableListOf<File>()

    private val _secondaryLoading = MutableStateFlow(false)
    val secondaryLoading: StateFlow<Boolean> = _secondaryLoading.asStateFlow()

    private val _activePaneIndex = MutableStateFlow(0) // 0: Pane A (Primary), 1: Pane B (Secondary)
    val activePaneIndex: StateFlow<Int> = _activePaneIndex.asStateFlow()

    private val _storageVolumes = MutableStateFlow<List<StorageVolumeInfo>>(emptyList())
    val storageVolumes: StateFlow<List<StorageVolumeInfo>> = _storageVolumes.asStateFlow()

    private val _clipboard = MutableStateFlow<ClipboardState?>(null)
    val clipboard: StateFlow<ClipboardState?> = _clipboard.asStateFlow()

    private val _selectedItems = MutableStateFlow<Set<FileItem>>(emptySet())
    val selectedItems: StateFlow<Set<FileItem>> = _selectedItems.asStateFlow()

    private val _isMultiSelectMode = MutableStateFlow<Boolean>(false)
    val isMultiSelectMode: StateFlow<Boolean> = _isMultiSelectMode.asStateFlow()

    private val _sortOption = MutableStateFlow(SortOption(SortField.NAME, SortOrder.ASCENDING))
    val sortOption: StateFlow<SortOption> = _sortOption.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _showHiddenFiles = MutableStateFlow(prefs.getBoolean("show_hidden_files", false))
    val showHiddenFiles: StateFlow<Boolean> = _showHiddenFiles.asStateFlow()

    private val _isGridView = MutableStateFlow(prefs.getBoolean("is_grid_view", false))
    val isGridView: StateFlow<Boolean> = _isGridView.asStateFlow()

    private val _orientationMode = MutableStateFlow(
        runCatching {
            AppOrientationMode.valueOf(prefs.getString("orientation_mode", AppOrientationMode.AUTO.name) ?: AppOrientationMode.AUTO.name)
        }.getOrDefault(AppOrientationMode.AUTO)
    )
    val orientationMode: StateFlow<AppOrientationMode> = _orientationMode.asStateFlow()

    private val _favorites = MutableStateFlow<Set<String>>(prefs.getStringSet("favorites", emptySet()) ?: emptySet())
    val favorites: StateFlow<Set<String>> = _favorites.asStateFlow()

    private val _recentFilePaths = MutableStateFlow<List<String>>(
        prefs.getString("recent_files", "")?.split(",")?.filter { it.isNotBlank() } ?: emptyList()
    )
    val recentFilePaths: StateFlow<List<String>> = _recentFilePaths.asStateFlow()

    private val _operationProgress = MutableStateFlow(OperationProgress())
    val operationProgress: StateFlow<OperationProgress> = _operationProgress.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    init {
        refreshStorageVolumes()
        loadDirectory(_currentDirectory.value)
        viewModelScope.launch {
            CrossWindowTransferBus.events.collect { event ->
                val affectedDirs = buildSet {
                    add(event.targetDirectoryPath)
                    event.sourcePaths.forEach { path ->
                        File(path).parentFile?.absolutePath?.let { add(it) }
                    }
                }
                if (event.isMove) {
                    val movedSet = event.sourcePaths.toSet()
                    val remaining = _selectedItems.value.filterNot { movedSet.contains(it.path) }.toSet()
                    _selectedItems.value = remaining
                    _isMultiSelectMode.value = remaining.isNotEmpty()
                }
                if (affectedDirs.contains(_currentDirectory.value.absolutePath)) {
                    loadDirectory(_currentDirectory.value, preserveSelection = !event.isMove)
                }
                if (_isDualPaneMode.value && affectedDirs.contains(_secondaryDirectory.value.absolutePath)) {
                    loadSecondaryDirectory(_secondaryDirectory.value)
                }
            }
        }
    }

    fun setOrientationMode(mode: AppOrientationMode) {
        _orientationMode.value = mode
        prefs.edit().putString("orientation_mode", mode.name).apply()
    }

    fun cycleOrientationMode() {
        val next = when (_orientationMode.value) {
            AppOrientationMode.AUTO -> AppOrientationMode.PORTRAIT
            AppOrientationMode.PORTRAIT -> AppOrientationMode.LANDSCAPE
            AppOrientationMode.LANDSCAPE -> AppOrientationMode.AUTO
        }
        setOrientationMode(next)
    }

    fun initFromWindowIntent(startInFiles: Boolean, initialPath: String?) {
        val targetDir = initialPath?.let { File(it) }?.takeIf { it.exists() && it.isDirectory && it.canRead() }
        if (targetDir != null) {
            loadDirectory(targetDir)
        }
        if (startInFiles) {
            _navigationHistory.clear()
            _navigationHistory.add(ScreenDestination.Home)
            _currentScreen.value = ScreenDestination.Files
        }
    }

    fun syncDualPaneSplitForOrientation(isLandscape: Boolean) {
        val target = if (isLandscape) DualPaneSplit.VERTICAL else DualPaneSplit.HORIZONTAL
        if (_dualPaneSplit.value != target) {
            _dualPaneSplit.value = target
        }
    }

    fun navigateTo(destination: ScreenDestination) {
        if (_currentScreen.value != destination) {
            _navigationHistory.add(_currentScreen.value)
            _currentScreen.value = destination
        }
    }

    /**
     * Proper Back navigation:
     * When inside Files (Internal Storage), retraces folder-by-folder in exact reverse order
     * rather than jumping straight out to Home!
     */
    fun navigateBack(): Boolean {
        // If in Files screen:
        if (_currentScreen.value is ScreenDestination.Files) {
            // Cancel search first if active
            if (_searchQuery.value.isNotBlank()) {
                _searchQuery.value = ""
                return true
            }

            // Pop folder backstack in primary pane (retraces exact folder path entered, preserving selection across directories when in selection mode!)
            if (_directoryBackStack.isNotEmpty()) {
                val previousDir = _directoryBackStack.removeAt(_directoryBackStack.size - 1)
                loadDirectory(previousDir, preserveSelection = _isMultiSelectMode.value)
                return true
            }

            // Exit multi-select mode when at the top of the folder backstack
            if (_isMultiSelectMode.value) {
                clearSelection()
                return true
            }

            // If backstack is empty, check if current directory is a child of root storage
            val parent = _currentDirectory.value.parentFile
            val internalRoot = Environment.getExternalStorageDirectory()
            if (parent != null && parent.canRead() && _currentDirectory.value.absolutePath != internalRoot.absolutePath) {
                loadDirectory(parent, preserveSelection = _isMultiSelectMode.value)
                return true
            }

            // At root of storage: pop navigation history if user navigated here from another screen
            if (_navigationHistory.isNotEmpty()) {
                _currentScreen.value = _navigationHistory.removeAt(_navigationHistory.size - 1)
                return true
            }
            return false
        }

        // For sub-screens (TextViewer, ApkInspector, HexViewer, Settings, etc.):
        if (_navigationHistory.isNotEmpty()) {
            _currentScreen.value = _navigationHistory.removeAt(_navigationHistory.size - 1)
            return true
        }

        if (_currentScreen.value !is ScreenDestination.Home) {
            _currentScreen.value = ScreenDestination.Home
            return true
        }

        return false
    }

    fun canNavigateBack(): Boolean {
        if (_currentScreen.value is ScreenDestination.Files) {
            if (_searchQuery.value.isNotBlank()) return true
            if (_isMultiSelectMode.value) return true
            if (_activeCategoryTitle.value != null) return true
            if (_directoryBackStack.isNotEmpty()) return true
            val parent = _currentDirectory.value.parentFile
            val internalRoot = Environment.getExternalStorageDirectory()
            if (parent != null && parent.canRead() && _currentDirectory.value.absolutePath != internalRoot.absolutePath) return true
            return _navigationHistory.isNotEmpty()
        }
        return _currentScreen.value !is ScreenDestination.Home
    }

    fun refreshStorageVolumes() {
        viewModelScope.launch {
            val volumes = withContext(Dispatchers.IO) {
                FileOperations.getStorageVolumes(getApplication())
            }
            _storageVolumes.value = volumes
        }
    }

    fun openStorageRoot(directory: File) {
        _directoryBackStack.clear()
        _activeCategoryTitle.value = null
        loadDirectory(directory, preserveSelection = _isMultiSelectMode.value)
        navigateTo(ScreenDestination.Files)
    }

    /**
     * Enters a directory and records the previous directory in backstack
     */
    fun enterDirectory(directory: File) {
        if (_currentDirectory.value.absolutePath != directory.absolutePath) {
            _directoryBackStack.add(_currentDirectory.value)
        }
        loadDirectory(directory, preserveSelection = _isMultiSelectMode.value)
    }

    fun enterSecondaryDirectory(directory: File) {
        if (_secondaryDirectory.value.absolutePath != directory.absolutePath) {
            _secondaryBackStack.add(_secondaryDirectory.value)
        }
        loadSecondaryDirectory(directory)
    }

    fun loadCategoryFiles(fileType: FileType, categoryTitle: String) {
        _isLoading.value = true
        _activeCategoryTitle.value = categoryTitle
        _selectedItems.value = emptySet()
        _isMultiSelectMode.value = false
        _directoryBackStack.clear()
        navigateTo(ScreenDestination.Files)

        viewModelScope.launch {
            val items = withContext(Dispatchers.IO) {
                val list = mutableListOf<FileItem>()
                val root = Environment.getExternalStorageDirectory()
                val candidateDirs = listOf(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                    root
                ).filter { it != null && it.exists() && it.canRead() }

                val seenPaths = mutableSetOf<String>()
                fun scan(dir: File, depth: Int) {
                    if (depth > 3 || list.size >= 250) return
                    dir.listFiles()?.forEach { f ->
                        if (f.name.startsWith(".")) return@forEach
                        if (f.isDirectory) {
                            scan(f, depth + 1)
                        } else if (seenPaths.add(f.absolutePath)) {
                            if (FileUtils.detectFileType(f) == fileType) {
                                val ext = FileUtils.getExtension(f.name)
                                list.add(
                                    FileItem(
                                        name = f.name,
                                        path = f.absolutePath,
                                        size = f.length(),
                                        lastModified = f.lastModified(),
                                        isDirectory = false,
                                        isFavorite = _favorites.value.contains(f.absolutePath),
                                        fileType = fileType,
                                        mimeType = FileUtils.getMimeType(f.name),
                                        extension = ext,
                                        childCount = 0,
                                        isReadable = f.canRead(),
                                        isWritable = f.canWrite()
                                    )
                                )
                            }
                        }
                    }
                }

                for (dir in candidateDirs) {
                    scan(dir, 0)
                }
                sortFileList(list, _sortOption.value)
            }
            _fileItems.value = items
            _isLoading.value = false
        }
    }

    fun loadDirectory(directory: File, preserveSelection: Boolean = false) {
        _isLoading.value = true
        _activeCategoryTitle.value = null
        if (!preserveSelection) {
            _selectedItems.value = emptySet()
            _isMultiSelectMode.value = false
        }
        _currentDirectory.value = directory

        viewModelScope.launch {
            val items = withContext(Dispatchers.IO) {
                val list = mutableListOf<FileItem>()
                val files = directory.listFiles()
                if (files != null) {
                    val showHidden = _showHiddenFiles.value
                    for (f in files) {
                        if (!showHidden && f.name.startsWith(".")) continue
                        val isDir = f.isDirectory
                        val ext = FileUtils.getExtension(f.name)
                        val type = FileUtils.detectFileType(f)
                        val childCount = if (isDir) (f.listFiles()?.size ?: 0) else 0

                        list.add(
                            FileItem(
                                name = f.name,
                                path = f.absolutePath,
                                size = f.length(),
                                lastModified = f.lastModified(),
                                isDirectory = isDir,
                                isFavorite = _favorites.value.contains(f.absolutePath),
                                fileType = type,
                                mimeType = FileUtils.getMimeType(f.name),
                                extension = ext,
                                childCount = childCount,
                                isReadable = f.canRead(),
                                isWritable = f.canWrite()
                            )
                        )
                    }
                }
                sortFileList(list, _sortOption.value)
            }
            _fileItems.value = items
            _isLoading.value = false
        }
    }

    fun loadSecondaryDirectory(directory: File) {
        _secondaryLoading.value = true
        _secondaryDirectory.value = directory

        viewModelScope.launch {
            val items = withContext(Dispatchers.IO) {
                val list = mutableListOf<FileItem>()
                val files = directory.listFiles()
                if (files != null) {
                    val showHidden = _showHiddenFiles.value
                    for (f in files) {
                        if (!showHidden && f.name.startsWith(".")) continue
                        val isDir = f.isDirectory
                        val ext = FileUtils.getExtension(f.name)
                        val type = FileUtils.detectFileType(f)
                        val childCount = if (isDir) (f.listFiles()?.size ?: 0) else 0

                        list.add(
                            FileItem(
                                name = f.name,
                                path = f.absolutePath,
                                size = f.length(),
                                lastModified = f.lastModified(),
                                isDirectory = isDir,
                                isFavorite = _favorites.value.contains(f.absolutePath),
                                fileType = type,
                                mimeType = FileUtils.getMimeType(f.name),
                                extension = ext,
                                childCount = childCount,
                                isReadable = f.canRead(),
                                isWritable = f.canWrite()
                            )
                        )
                    }
                }
                sortFileList(list, _sortOption.value)
            }
            _secondaryFileItems.value = items
            _secondaryLoading.value = false
        }
    }

    // Dual Pane Helpers
    fun toggleDualPane(enable: Boolean? = null) {
        val newVal = enable ?: !_isDualPaneMode.value
        _isDualPaneMode.value = newVal
        if (newVal && _secondaryFileItems.value.isEmpty()) {
            loadSecondaryDirectory(_secondaryDirectory.value)
        }
    }

    fun toggleDualPaneSplit() {
        _dualPaneSplit.value = if (_dualPaneSplit.value == DualPaneSplit.VERTICAL) {
            DualPaneSplit.HORIZONTAL
        } else {
            DualPaneSplit.VERTICAL
        }
    }

    fun setActivePane(index: Int) {
        _activePaneIndex.value = index
    }

    fun transferFileBetweenPanes(fileItem: FileItem, targetDir: File, isMove: Boolean) {
        viewModelScope.launch {
            val src = File(fileItem.path)
            _isLoading.value = true
            _secondaryLoading.value = true
            val success = withContext(Dispatchers.IO) {
                try {
                    val res = if (isMove) {
                        FileOperations.moveFileOrDirectory(src, targetDir)
                    } else {
                        FileOperations.copyFileOrDirectory(src, targetDir)
                    }
                    res.isSuccess
                } catch (e: Exception) {
                    false
                }
            }
            if (success) {
                _statusMessage.value = if (isMove) "Đã di chuyển: ${fileItem.name}" else "Đã sao chép: ${fileItem.name}"
                loadDirectory(_currentDirectory.value)
                loadSecondaryDirectory(_secondaryDirectory.value)
            } else {
                _statusMessage.value = "Không thể chuyển tệp (kiểm tra quyền truy cập)"
                _isLoading.value = false
                _secondaryLoading.value = false
            }
        }
    }

    fun transferExternalPaths(
        sourcePaths: List<String>,
        targetDir: File,
        isMove: Boolean,
        targetWindowId: String
    ) {
        val uniquePaths = sourcePaths.distinct()
        if (uniquePaths.isEmpty()) return

        viewModelScope.launch {
            _operationProgress.value = OperationProgress(
                isRunning = true,
                title = if (isMove) "Đang cắt & di chuyển..." else "Đang sao chép...",
                totalFiles = uniquePaths.size
            )

            var successCount = 0
            var skippedSameOrNested = 0
            val succeededPaths = mutableListOf<String>()

            withContext(Dispatchers.IO) {
                targetDir.mkdirs()
                val targetCanonical = runCatching { targetDir.canonicalPath }.getOrDefault(targetDir.absolutePath)

                uniquePaths.forEachIndexed { index, rawPath ->
                    val src = File(rawPath)
                    _operationProgress.value = _operationProgress.value.copy(
                        currentFileIndex = index + 1,
                        currentFileName = src.name,
                        progress = (index + 1).toFloat() / uniquePaths.size.toFloat()
                    )
                    if (!src.exists()) return@forEachIndexed

                    val srcCanonical = runCatching { src.canonicalPath }.getOrDefault(src.absolutePath)
                    val srcParentCanonical = runCatching { src.parentFile?.canonicalPath }.getOrNull()

                    // Guard against dropping folder into itself or moving into same directory
                    if (src.isDirectory && (targetCanonical == srcCanonical || targetCanonical.startsWith(srcCanonical + File.separator))) {
                        skippedSameOrNested++
                        return@forEachIndexed
                    }
                    if (isMove && srcParentCanonical == targetCanonical) {
                        skippedSameOrNested++
                        return@forEachIndexed
                    }

                    val res = if (isMove) {
                        FileOperations.moveFileOrDirectory(src, targetDir)
                    } else {
                        FileOperations.copyFileOrDirectory(src, targetDir)
                    }
                    if (res.isSuccess) {
                        successCount++
                        succeededPaths.add(rawPath)
                    }
                }
            }

            _operationProgress.value = OperationProgress(isRunning = false)
            val targetName = targetDir.name.ifEmpty { "thư mục đích" }
            when {
                successCount > 0 -> {
                    val actionLabel = if (isMove) "Đã cắt & chuyển" else "Đã sao chép"
                    _statusMessage.value = "$actionLabel $successCount/${uniquePaths.size} mục vào $targetName"
                    loadDirectory(_currentDirectory.value)
                    if (_isDualPaneMode.value) loadSecondaryDirectory(_secondaryDirectory.value)
                    CrossWindowTransferBus.emit(
                        CrossWindowTransferEvent(
                            sourcePaths = succeededPaths,
                            targetDirectoryPath = targetDir.absolutePath,
                            isMove = isMove,
                            targetWindowId = targetWindowId
                        )
                    )
                }
                skippedSameOrNested > 0 -> {
                    _statusMessage.value = "Không thể chuyển thư mục vào chính nó hoặc cùng vị trí"
                }
                else -> {
                    _statusMessage.value = "Không thể xử lý tệp (kiểm tra quyền lưu trữ)"
                }
            }
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSortOption(option: SortOption) {
        _sortOption.value = option
        _fileItems.value = sortFileList(_fileItems.value, option)
        _secondaryFileItems.value = sortFileList(_secondaryFileItems.value, option)
    }

    private fun sortFileList(list: List<FileItem>, option: SortOption): List<FileItem> {
        val comparator = when (option.field) {
            SortField.NAME -> compareBy<FileItem> { it.name.lowercase() }
            SortField.DATE -> compareBy { it.lastModified }
            SortField.SIZE -> compareBy { it.size }
            SortField.TYPE -> compareBy { it.extension }
        }

        val sorted = if (option.order == SortOrder.ASCENDING) {
            list.sortedWith(comparator)
        } else {
            list.sortedWith(comparator.reversed())
        }

        // Directories always appear on top
        return sorted.sortedByDescending { it.isDirectory }
    }

    fun toggleViewMode() {
        val newMode = !_isGridView.value
        _isGridView.value = newMode
        prefs.edit().putBoolean("is_grid_view", newMode).apply()
    }

    fun toggleGridView() = toggleViewMode()

    fun toggleShowHiddenFiles() {
        val newShow = !_showHiddenFiles.value
        _showHiddenFiles.value = newShow
        prefs.edit().putBoolean("show_hidden_files", newShow).apply()
        loadDirectory(_currentDirectory.value)
        if (_isDualPaneMode.value) loadSecondaryDirectory(_secondaryDirectory.value)
    }

    fun toggleFavorite(fileItem: FileItem) {
        val newFavs = _favorites.value.toMutableSet()
        if (newFavs.contains(fileItem.path)) {
            newFavs.remove(fileItem.path)
        } else {
            newFavs.add(fileItem.path)
        }
        _favorites.value = newFavs
        prefs.edit().putStringSet("favorites", newFavs).apply()

        _fileItems.value = _fileItems.value.map {
            if (it.path == fileItem.path) it.copy(isFavorite = newFavs.contains(it.path)) else it
        }
        _secondaryFileItems.value = _secondaryFileItems.value.map {
            if (it.path == fileItem.path) it.copy(isFavorite = newFavs.contains(it.path)) else it
        }
    }

    fun addRecentFile(file: File) {
        val list = _recentFilePaths.value.toMutableList()
        list.remove(file.absolutePath)
        list.add(0, file.absolutePath)
        val trimmed = list.take(15)
        _recentFilePaths.value = trimmed
        prefs.edit().putString("recent_files", trimmed.joinToString(",")).apply()
    }

    fun enterSelectionMode() {
        _isMultiSelectMode.value = true
    }

    fun toggleSelectionMode() {
        if (_isMultiSelectMode.value) {
            clearSelection()
        } else {
            enterSelectionMode()
        }
    }

    fun toggleSelectItem(item: FileItem) {
        val current = _selectedItems.value
        val updated = if (current.any { it.path == item.path }) {
            current.filterNot { it.path == item.path }.toSet()
        } else {
            current + item
        }
        _selectedItems.value = updated
        _isMultiSelectMode.value = true
    }

    fun removeSelectedPath(path: String) {
        _selectedItems.value = _selectedItems.value.filterNot { it.path == path }.toSet()
    }

    fun selectAll(displayedInActivePane: List<FileItem>? = null) {
        val targetItems = displayedInActivePane ?: if (_isDualPaneMode.value && _activePaneIndex.value == 1) {
            _secondaryFileItems.value
        } else {
            _fileItems.value
        }
        val existingPaths = _selectedItems.value.map { it.path }.toSet()
        val additions = targetItems.filterNot { existingPaths.contains(it.path) }
        _selectedItems.value = _selectedItems.value + additions
        _isMultiSelectMode.value = true
    }

    fun invertSelectionInDirectory(displayedItems: List<FileItem>) {
        val dirPaths = displayedItems.map { it.path }.toSet()
        val currentlySelected = _selectedItems.value
        val selectedPathsInDir = currentlySelected.filter { dirPaths.contains(it.path) }.map { it.path }.toSet()
        val keptFromOtherDirs = currentlySelected.filterNot { dirPaths.contains(it.path) }
        val invertedInDir = displayedItems.filterNot { selectedPathsInDir.contains(it.path) }
        _selectedItems.value = (keptFromOtherDirs + invertedInDir).toSet()
        _isMultiSelectMode.value = true
    }

    fun deselectCurrentDirectory(displayedItems: List<FileItem>) {
        val dirPaths = displayedItems.map { it.path }.toSet()
        _selectedItems.value = _selectedItems.value.filterNot { dirPaths.contains(it.path) }.toSet()
    }

    fun clearSelection() {
        _selectedItems.value = emptySet()
        _isMultiSelectMode.value = false
    }

    fun batchMoveOrCopySelected(
        targetDir: File,
        isMove: Boolean,
        windowInstanceId: String = "batch"
    ) {
        val items = _selectedItems.value.toList()
        if (items.isEmpty()) return

        viewModelScope.launch {
            _operationProgress.value = OperationProgress(
                isRunning = true,
                title = if (isMove) "Đang di chuyển ${items.size} mục..." else "Đang sao chép ${items.size} mục...",
                totalFiles = items.size
            )

            var successCount = 0
            var skippedCount = 0
            val succeededPaths = mutableListOf<String>()

            withContext(Dispatchers.IO) {
                targetDir.mkdirs()
                val targetCanonical = runCatching { targetDir.canonicalPath }.getOrDefault(targetDir.absolutePath)

                items.forEachIndexed { index, item ->
                    val src = File(item.path)
                    _operationProgress.value = _operationProgress.value.copy(
                        currentFileIndex = index + 1,
                        currentFileName = item.name,
                        progress = (index + 1).toFloat() / items.size.toFloat()
                    )
                    if (!src.exists()) return@forEachIndexed

                    val srcCanonical = runCatching { src.canonicalPath }.getOrDefault(src.absolutePath)
                    val srcParentCanonical = runCatching { src.parentFile?.canonicalPath }.getOrNull()

                    if (src.isDirectory && (targetCanonical == srcCanonical || targetCanonical.startsWith(srcCanonical + File.separator))) {
                        skippedCount++
                        return@forEachIndexed
                    }
                    if (isMove && srcParentCanonical == targetCanonical) {
                        skippedCount++
                        return@forEachIndexed
                    }

                    val res = if (isMove) {
                        FileOperations.moveFileOrDirectory(src, targetDir)
                    } else {
                        FileOperations.copyFileOrDirectory(src, targetDir)
                    }
                    if (res.isSuccess) {
                        successCount++
                        succeededPaths.add(item.path)
                    }
                }
            }

            _operationProgress.value = OperationProgress(isRunning = false)
            val targetName = targetDir.name.ifEmpty { targetDir.absolutePath }
            when {
                successCount > 0 -> {
                    clearSelection()
                    val verb = if (isMove) "Đã di chuyển" else "Đã sao chép"
                    val skipNote = if (skippedCount > 0) " (bỏ qua $skippedCount mục trùng/lồng)" else ""
                    _statusMessage.value = "$verb $successCount/${items.size} mục vào $targetName$skipNote"
                    loadDirectory(_currentDirectory.value)
                    if (_isDualPaneMode.value) loadSecondaryDirectory(_secondaryDirectory.value)
                    CrossWindowTransferBus.emit(
                        CrossWindowTransferEvent(
                            sourcePaths = succeededPaths,
                            targetDirectoryPath = targetDir.absolutePath,
                            isMove = isMove,
                            targetWindowId = windowInstanceId
                        )
                    )
                }
                skippedCount > 0 -> {
                    _statusMessage.value = "Không thể chuyển thư mục vào chính nó hoặc cùng thư mục hiện tại"
                }
                else -> {
                    _statusMessage.value = "Không thể xử lý tệp (kiểm tra quyền truy cập)"
                }
            }
        }
    }

    fun setClipboard(action: ClipboardAction) {
        if (_selectedItems.value.isNotEmpty()) {
            _clipboard.value = ClipboardState(action = action, items = _selectedItems.value.toList())
            clearSelection()
            _statusMessage.value = "Đã lưu ${_clipboard.value?.items?.size} tệp vào khay nhớ tạm"
        }
    }

    fun setClipboardItems(action: ClipboardAction, items: List<FileItem>) {
        if (items.isEmpty()) return
        _clipboard.value = ClipboardState(action = action, items = items)
        val verb = if (action == ClipboardAction.COPY) "sao chép" else "cắt"
        val label = if (items.size == 1) items.first().name else "${items.size} mục"
        _statusMessage.value = "Đã $verb \"$label\" — mở thư mục đích và chọn Dán"
    }

    fun clearClipboard() {
        _clipboard.value = null
    }

    fun pasteClipboard(targetDirectory: File = _currentDirectory.value) {
        val clip = _clipboard.value ?: return
        viewModelScope.launch {
            _operationProgress.value = OperationProgress(
                isRunning = true,
                title = if (clip.action == ClipboardAction.COPY) "Đang sao chép..." else "Đang di chuyển...",
                totalFiles = clip.items.size
            )

            var successCount = 0
            var skippedSameOrNested = 0
            withContext(Dispatchers.IO) {
                targetDirectory.mkdirs()
                val targetCanonical = runCatching { targetDirectory.canonicalPath }.getOrDefault(targetDirectory.absolutePath)
                clip.items.forEachIndexed { index, item ->
                    _operationProgress.value = _operationProgress.value.copy(
                        currentFileIndex = index + 1,
                        currentFileName = item.name,
                        progress = if (clip.items.isNotEmpty()) (index + 1).toFloat() / clip.items.size.toFloat() else 1f
                    )
                    val src = File(item.path)
                    if (!src.exists()) return@forEachIndexed
                    val srcCanonical = runCatching { src.canonicalPath }.getOrDefault(src.absolutePath)
                    val srcParentCanonical = runCatching { src.parentFile?.canonicalPath }.getOrNull()

                    if (src.isDirectory && (targetCanonical == srcCanonical || targetCanonical.startsWith(srcCanonical + File.separator))) {
                        skippedSameOrNested++
                        return@forEachIndexed
                    }
                    if (clip.action == ClipboardAction.CUT && srcParentCanonical == targetCanonical) {
                        skippedSameOrNested++
                        return@forEachIndexed
                    }

                    val res = if (clip.action == ClipboardAction.COPY) {
                        FileOperations.copyFileOrDirectory(src, targetDirectory)
                    } else {
                        FileOperations.moveFileOrDirectory(src, targetDirectory)
                    }
                    if (res.isSuccess) successCount++
                }
            }

            _operationProgress.value = OperationProgress(isRunning = false)
            val targetName = targetDirectory.name.ifEmpty { targetDirectory.absolutePath }
            when {
                successCount > 0 -> {
                    val verb = if (clip.action == ClipboardAction.COPY) "Đã sao chép" else "Đã di chuyển"
                    _statusMessage.value = "$verb $successCount mục vào $targetName"
                    if (clip.action == ClipboardAction.CUT) clearClipboard()
                    loadDirectory(_currentDirectory.value)
                    if (_isDualPaneMode.value) loadSecondaryDirectory(_secondaryDirectory.value)
                }
                skippedSameOrNested > 0 -> {
                    _statusMessage.value = "Không thể dán thư mục vào chính nó hoặc cùng vị trí"
                }
                else -> {
                    _statusMessage.value = "Không thể xử lý tệp"
                }
            }
        }
    }

    fun moveOrCopySingleItem(item: FileItem, targetDir: File, isMove: Boolean) {
        viewModelScope.launch {
            _operationProgress.value = OperationProgress(
                isRunning = true,
                title = if (isMove) "Đang di chuyển ${item.name}..." else "Đang sao chép ${item.name}...",
                totalFiles = 1,
                currentFileIndex = 1,
                currentFileName = item.name,
                progress = 0.5f
            )
            var skipped = false
            val ok = withContext(Dispatchers.IO) {
                val src = File(item.path)
                if (!src.exists()) return@withContext false
                targetDir.mkdirs()
                val targetCanonical = runCatching { targetDir.canonicalPath }.getOrDefault(targetDir.absolutePath)
                val srcCanonical = runCatching { src.canonicalPath }.getOrDefault(src.absolutePath)
                val srcParentCanonical = runCatching { src.parentFile?.canonicalPath }.getOrNull()

                if (src.isDirectory && (targetCanonical == srcCanonical || targetCanonical.startsWith(srcCanonical + File.separator))) {
                    skipped = true
                    return@withContext false
                }
                if (isMove && srcParentCanonical == targetCanonical) {
                    skipped = true
                    return@withContext false
                }

                val res = if (isMove) {
                    FileOperations.moveFileOrDirectory(src, targetDir)
                } else {
                    FileOperations.copyFileOrDirectory(src, targetDir)
                }
                res.isSuccess
            }
            _operationProgress.value = OperationProgress(isRunning = false)
            val targetName = targetDir.name.ifEmpty { targetDir.absolutePath }
            when {
                ok -> {
                    _statusMessage.value = if (isMove) "Đã di chuyển ${item.name} vào $targetName" else "Đã sao chép ${item.name} vào $targetName"
                    loadDirectory(_currentDirectory.value)
                    if (_isDualPaneMode.value) loadSecondaryDirectory(_secondaryDirectory.value)
                }
                skipped -> {
                    _statusMessage.value = "Không thể chuyển thư mục vào chính nó hoặc cùng vị trí"
                }
                else -> {
                    _statusMessage.value = "Không thể xử lý tệp (kiểm tra quyền truy cập)"
                }
            }
        }
    }

    fun openFile(fileItem: FileItem) {
        val file = File(fileItem.path)
        if (!file.exists()) {
            _statusMessage.value = "Tệp không tồn tại"
            return
        }

        if (fileItem.isDirectory) {
            _activeCategoryTitle.value = null
            enterDirectory(file)
            navigateTo(ScreenDestination.Files)
            return
        }

        addRecentFile(file)

        when (fileItem.fileType) {
            FileType.APK -> navigateTo(ScreenDestination.ApkInspector(file))
            FileType.DATABASE -> navigateTo(ScreenDestination.SqliteViewer(file))
            FileType.ARCHIVE -> navigateTo(ScreenDestination.ArchiveViewer(file))
            FileType.TEXT_CODE -> navigateTo(ScreenDestination.TextViewer(file))
            FileType.IMAGE, FileType.AUDIO, FileType.VIDEO -> navigateTo(ScreenDestination.MediaViewer(file, fileItem.fileType))
            FileType.GAME_DATA -> {
                val ext = fileItem.extension
                when (ext) {
                    "obb", "zip" -> navigateTo(ScreenDestination.ArchiveViewer(file))
                    "db", "sqlite" -> navigateTo(ScreenDestination.SqliteViewer(file))
                    "json", "xml", "txt", "ini", "cfg", "txs", "ts", "css", "bat" -> navigateTo(ScreenDestination.TextViewer(file))
                    "dat" -> {
                        if (FileUtils.isLikelyTextFile(file)) {
                            navigateTo(ScreenDestination.TextViewer(file))
                        } else {
                            navigateTo(ScreenDestination.HexViewer(file))
                        }
                    }
                    else -> navigateTo(ScreenDestination.HexViewer(file))
                }
            }
            else -> {
                if (FileUtils.isLikelyTextFile(file)) {
                    navigateTo(ScreenDestination.TextViewer(file))
                } else {
                    navigateTo(ScreenDestination.HexViewer(file))
                }
            }
        }
    }

    fun createFolder(name: String, inSecondaryPane: Boolean = false) {
        val target = if (inSecondaryPane) _secondaryDirectory.value else _currentDirectory.value
        viewModelScope.launch {
            val res = withContext(Dispatchers.IO) {
                FileOperations.createNewFolder(target, name)
            }
            if (res.isSuccess) {
                _statusMessage.value = "Đã tạo thư mục: $name"
                if (inSecondaryPane) loadSecondaryDirectory(target) else loadDirectory(target)
            } else {
                _statusMessage.value = res.exceptionOrNull()?.message ?: "Không thể tạo thư mục"
            }
        }
    }

    fun createFile(name: String, inSecondaryPane: Boolean = false) {
        val target = if (inSecondaryPane) _secondaryDirectory.value else _currentDirectory.value
        viewModelScope.launch {
            val res = withContext(Dispatchers.IO) {
                FileOperations.createNewFile(target, name)
            }
            if (res.isSuccess) {
                _statusMessage.value = "Đã tạo tệp: $name"
                if (inSecondaryPane) loadSecondaryDirectory(target) else loadDirectory(target)
            } else {
                _statusMessage.value = res.exceptionOrNull()?.message ?: "Không thể tạo tệp"
            }
        }
    }

    fun renameFile(item: FileItem, newName: String) {
        viewModelScope.launch {
            val res = withContext(Dispatchers.IO) {
                FileOperations.rename(File(item.path), newName)
            }
            if (res.isSuccess) {
                _statusMessage.value = "Đã đổi tên thành công"
                loadDirectory(_currentDirectory.value)
                if (_isDualPaneMode.value) loadSecondaryDirectory(_secondaryDirectory.value)
            } else {
                _statusMessage.value = res.exceptionOrNull()?.message ?: "Không thể đổi tên tệp"
            }
        }
    }

    fun deleteSelectedItems() {
        val items = _selectedItems.value.toList()
        if (items.isEmpty()) return

        viewModelScope.launch {
            _operationProgress.value = OperationProgress(
                isRunning = true,
                title = "Đang xóa ${items.size} mục...",
                totalFiles = items.size
            )

            var deletedCount = 0
            val deletedPaths = mutableListOf<String>()
            withContext(Dispatchers.IO) {
                items.forEachIndexed { index, item ->
                    _operationProgress.value = _operationProgress.value.copy(
                        currentFileIndex = index + 1,
                        currentFileName = item.name,
                        progress = if (items.isNotEmpty()) (index + 1).toFloat() / items.size.toFloat() else 1f
                    )
                    val res = FileOperations.deleteRecursively(File(item.path))
                    if (res.isSuccess && res.getOrDefault(false)) {
                        deletedCount++
                        deletedPaths.add(item.path)
                    }
                }
            }

            _operationProgress.value = OperationProgress(isRunning = false)
            clearSelection()
            _statusMessage.value = "Đã xóa $deletedCount/${items.size} tệp/thư mục"
            loadDirectory(_currentDirectory.value)
            if (_isDualPaneMode.value) loadSecondaryDirectory(_secondaryDirectory.value)
            if (deletedPaths.isNotEmpty()) {
                CrossWindowTransferBus.emit(
                    CrossWindowTransferEvent(
                        sourcePaths = deletedPaths,
                        targetDirectoryPath = _currentDirectory.value.absolutePath,
                        isMove = true,
                        targetWindowId = "batch_delete"
                    )
                )
            }
        }
    }

    fun deleteSingleFile(item: FileItem) {
        viewModelScope.launch {
            val res = withContext(Dispatchers.IO) {
                FileOperations.deleteRecursively(File(item.path))
            }
            if (res.isSuccess && res.getOrDefault(false)) {
                _statusMessage.value = "Đã xóa ${item.name}"
                loadDirectory(_currentDirectory.value)
                if (_isDualPaneMode.value) loadSecondaryDirectory(_secondaryDirectory.value)
            } else {
                _statusMessage.value = "Không thể xóa tệp"
            }
        }
    }

    fun createZipFromSelected(archiveName: String) {
        val items = _selectedItems.value.toList()
        if (items.isEmpty()) return

        val targetZip = File(_currentDirectory.value, if (archiveName.endsWith(".zip")) archiveName else "$archiveName.zip")
        viewModelScope.launch {
            _operationProgress.value = OperationProgress(
                isRunning = true,
                title = "Đang nén tệp...",
                totalFiles = items.size
            )

            val res = withContext(Dispatchers.IO) {
                ArchiveManager.createZip(
                    sourceFiles = items.map { File(it.path) },
                    destinationZip = targetZip,
                    onProgress = { progress, name ->
                        _operationProgress.value = _operationProgress.value.copy(
                            progress = progress,
                            currentFileName = name
                        )
                    }
                )
            }

            _operationProgress.value = OperationProgress(isRunning = false)
            clearSelection()
            if (res.isSuccess) {
                _statusMessage.value = "Đã tạo tệp nén: ${targetZip.name}"
                loadDirectory(_currentDirectory.value)
                if (_isDualPaneMode.value) loadSecondaryDirectory(_secondaryDirectory.value)
            } else {
                _statusMessage.value = "Lỗi khi nén: ${res.exceptionOrNull()?.message}"
            }
        }
    }

    fun createArchiveFromFiles(
        sourceFiles: List<File>,
        config: ArchiveCompressionConfig
    ) {
        if (sourceFiles.isEmpty()) {
            _statusMessage.value = "Không có tệp nguồn nào để nén"
            return
        }

        viewModelScope.launch {
            _operationProgress.value = OperationProgress(
                isRunning = true,
                title = "Đang tạo tệp lưu trữ (${config.format.displayName})...",
                totalFiles = sourceFiles.size
            )

            val res = withContext(Dispatchers.IO) {
                ArchiveManager.createArchive(
                    sourceFiles = sourceFiles,
                    config = config,
                    onProgress = { progress, name ->
                        _operationProgress.value = _operationProgress.value.copy(
                            progress = progress,
                            currentFileName = name
                        )
                    }
                )
            }

            _operationProgress.value = OperationProgress(isRunning = false)
            clearSelection()
            if (res.isSuccess) {
                val created = res.getOrNull().orEmpty()
                val label = when {
                    created.size > 1 -> "${created.size} tệp (${created.first().name}...)"
                    created.size == 1 -> created.first().name
                    else -> config.archiveFileName
                }
                _statusMessage.value = "Đã nén thành công: $label tại ${config.destinationDir.name}"
                loadDirectory(_currentDirectory.value)
                if (_isDualPaneMode.value) loadSecondaryDirectory(_secondaryDirectory.value)
            } else {
                _statusMessage.value = "Lỗi khi nén: ${res.exceptionOrNull()?.message}"
            }
        }
    }

    fun extractArchiveToDirectory(
        archiveFile: File,
        targetDir: File,
        password: String? = null,
        onPasswordRequired: (() -> Unit)? = null
    ) {
        viewModelScope.launch {
            _operationProgress.value = OperationProgress(
                isRunning = true,
                title = "Đang giải nén ${archiveFile.name}...",
                totalFiles = 1
            )

            val res = withContext(Dispatchers.IO) {
                ArchiveManager.extractAll(
                    archiveFile = archiveFile,
                    targetDir = targetDir,
                    password = password,
                    onProgress = { progress, name ->
                        _operationProgress.value = _operationProgress.value.copy(
                            progress = progress,
                            currentFileName = name
                        )
                    }
                )
            }

            _operationProgress.value = OperationProgress(isRunning = false)
            if (res.isSuccess) {
                val count = res.getOrDefault(0)
                _statusMessage.value = "Đã giải nén $count mục vào ${targetDir.name}"
                loadDirectory(_currentDirectory.value)
                if (_isDualPaneMode.value) loadSecondaryDirectory(_secondaryDirectory.value)
            } else {
                val err = res.exceptionOrNull()
                if (err is ArchivePasswordRequiredException && onPasswordRequired != null) {
                    onPasswordRequired()
                } else {
                    _statusMessage.value = "Lỗi giải nén: ${err?.message}"
                }
            }
        }
    }

    fun handleSafUri(uri: Uri) {
        SafManager.takePersistableUriPermission(getApplication(), uri)
        _statusMessage.value = "Đã cấp quyền truy cập qua SAF"
        refreshStorageVolumes()
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }
}
